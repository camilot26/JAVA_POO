public class EmpleadoTemporal extends Empleado{

    public EmpleadoTemporal(int idEmpleado, Double salario, String nombre, int edad) {
        super(idEmpleado, salario, nombre, edad);





    }
}
