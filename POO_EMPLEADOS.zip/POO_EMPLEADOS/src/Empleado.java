public class Empleado extends Persona{
private int idEmpleado;
private Double salario;


    public Empleado(int idEmpleado, Double salario, String nombre, int edad){

        super(nombre,edad);
        this.idEmpleado = idEmpleado;
        this.salario = salario;
    }
    public int getIdEmpleado(){
            return idEmpleado;


    }



    public Double getSalario(){
        return salario;

    }
    public void setSalario(){
        this.salario = salario;

    }
    public void setIdEmpleado(){
        this.idEmpleado = idEmpleado;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "idEmpleado=" + idEmpleado +
                ", salario=" + salario +
                '}';
    }



}
