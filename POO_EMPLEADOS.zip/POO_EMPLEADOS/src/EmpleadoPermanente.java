public class EmpleadoPermanente extends Empleado{

    public EmpleadoPermanente(int idEmpleado, Double salario, String nombre, int edad) {
        super(idEmpleado, salario, nombre, edad);





    }

}
