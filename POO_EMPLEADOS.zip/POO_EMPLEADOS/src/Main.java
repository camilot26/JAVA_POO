import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner objscan = new Scanner(System.in);
        GestionEmpleado empleado = new GestionEmpleado();


        System.out.println("escoja 1 0 2");
        for (int i = 0; i < 5; i++) {
            System.out.println("ingrese el opcion");
            int opcion = objscan.nextInt();
            if(opcion ==1){
                empleado.agregarEmpleado(objscan);

            }else{
                empleado.listarEmpleado(objscan);
            }


        }





    }
}