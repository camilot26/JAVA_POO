import java.util.ArrayList;
import java.util.Scanner;

public class GestionEmpleado {
    private ArrayList<EmpleadoTemporal> gestionEmpleadoTemporal;
    private ArrayList<EmpleadoPermanente> gestionEmpleadoPermanente;

    public GestionEmpleado() {
        this.gestionEmpleadoTemporal = new ArrayList<>();
        this.gestionEmpleadoPermanente = new ArrayList<>();
    }

    public void agregarEmpleado(Scanner objscan) {

        System.out.println("ingrese 1 para Empleado temporal // ingrese 2 Empleado Permanente");
        int codigo = objscan.nextInt();
        if (codigo == 1) {
            objscan.nextLine();
            System.out.println("ingrese el nombre del empleado");
            String nombre = objscan.nextLine();
            System.out.println("ingrese la cedula del empleado");
            int id = objscan.nextInt();
            System.out.println("ingrese la edad");
            int edad = objscan.nextInt();
            System.out.println("Ingrese el salario");
            Double salario = objscan.nextDouble();
            EmpleadoTemporal empleado = new EmpleadoTemporal(id, salario, nombre, edad);
            gestionEmpleadoTemporal.add(empleado);


        } else {
            objscan.nextLine();
            System.out.println("ingrese el nombre del empleado");
            String nombre = objscan.nextLine();
            System.out.println("ingrese la cedula del empleado");
            int id = objscan.nextInt();
            System.out.println("ingrese la edad");
            int edad = objscan.nextInt();
            System.out.println("Ingrese el salario");
            Double salario = objscan.nextDouble();
            EmpleadoPermanente empleado = new EmpleadoPermanente(id, salario, nombre, edad);
            gestionEmpleadoPermanente.add(empleado);


        }


    }
    public void listarEmpleado(Scanner objscan){
        System.out.println("ingrese 1 para Empleado temporal // ingrese 2 Empleado Permanente");
        int codigo = objscan.nextInt();
        switch (codigo){

            case 1:
                for(EmpleadoTemporal empleado: this.gestionEmpleadoTemporal){
                    System.out.println(empleado.toString());


                }


                break;

            case 2:
                for(EmpleadoPermanente empleado: this.gestionEmpleadoPermanente){
                    System.out.println(empleado.toString());


                }
                break;

            default:
                System.out.println("numero no valido");

                break;
        }

    }


}
